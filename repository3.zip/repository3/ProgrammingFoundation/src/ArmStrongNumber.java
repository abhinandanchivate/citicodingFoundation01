
public class ArmStrongNumber {

	
	// 153  : 1(3) + 3(3) + 5(3)
	//         1 + 27  + 125
	// 153
	
	public static void main(String[] args) {
		
		boolean result = isArmStrong(155);
		System.out.println(result);
	}
	
	public static boolean isArmStrong(int number) {
		
		
		int digit;
		int temp = number;
		int sum = 0;
		while(number>0) {
			digit = number % 10;
			sum = sum + digit*digit*digit;
			number = number/ 10;
			
		}
		
		if(temp == sum) {
			return true;
		}
		else {
			return false;
		}
		
	}
}


// perfect number : 

// 28 ===> 14 ===> 1 to 14 ===> all the numbers from 1 to 14 and will apply the complete div(remainder 0) ==> 1, 2, 4, 7 , 14